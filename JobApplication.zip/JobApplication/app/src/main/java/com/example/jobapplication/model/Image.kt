package com.example.jobapplication.model

data class Image(
    val image: Int
)
